#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <time.h>
#include <stdbool.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <errno.h>
#include <sys/sysinfo.h>
#include <sys/utsname.h>
#include <dirent.h>
#include <signal.h>
#include <fcntl.h>
#include <ctype.h>
#include <pthread.h>
#include <termios.h>
#include <sys/wait.h>
#include <openssl/bio.h>
#include <openssl/evp.h>
#include <openssl/buffer.h>
#include <sys/sendfile.h>

#define SERVERPORT 1234
#define SERVERIP "192.168.100.36" 
#define MAX_SIZE 1024
#define BUFFER_SIZE 1024
#define RECEIVED_DOCS_DIR "/home/hiuhiubianca/Desktop/PSO_proiect/ReceivedDocumentsClient/" // voi pune comentarii la functiile unde sunt cai harcodate
#define MAX_ARGS 64

char procesele_curente[1024][1024];
char pid_procese[1024][1024];
int nr_proc;

int client_socket;
pthread_t recvThread;
int serverRunning=1;

//functii prin care extrag informatii despre sistem
char* checkEndian()
{
    unsigned int num=1;
    char* ptr=(char*)&num;
    char little[]="Little Endian";
    char big[]="Big Endian";
    char* s;

    if(*ptr==1){
        s=(char*)malloc(sizeof(char)*strlen(little));
        strcpy(s,little);

        return s;
    }
    if(*ptr==0){
        s=(char*)malloc(sizeof(char)*strlen(big));
        strcpy(s,big);
        
        return s;
    }

    return NULL;
}

void CPUInfo(FILE* f)
{
    char* byteOrder=checkEndian();
    if(byteOrder!=NULL){
        fprintf(f,"Byte order: %s\n",byteOrder);
    }

    FILE* fcpu=fopen("/proc/cpuinfo","r");
    if(fcpu==NULL){
        perror("Eroare la deschidere /proc/cpu.");
        exit(-1);
    }

    char line[MAX_SIZE];
    int i=0;
    while(fgets(line,sizeof(line),fcpu)!=NULL){
        if(i==1 || i==4 || i==8 || i==12 ){
            fprintf(f,"%s",line);
        }
        i++;
    }
    fprintf(f,"\n");

    fclose(fcpu);
}

void RAMInfo(FILE* f)
{
    struct sysinfo mem_info;
    if (sysinfo(&mem_info) != 0) {
        perror("Eroare la obținerea informațiilor despre memorie");
        exit(-1);
    }

    fprintf(f,"--Memory--");
    fprintf(f, "\nTotal RAM: %lu MB\n", mem_info.totalram / 1024 / 1024);
    fprintf(f, "Free RAM: %lu MB\n", mem_info.freeram / 1024 / 1024);
    fprintf(f, "Used RAM: %lu MB\n\n", (mem_info.totalram - mem_info.freeram) / 1024 / 1024);
}

void BIOSInfo(FILE* f)
{
    FILE *bios_vendor_file = fopen("/sys/class/dmi/id/bios_vendor", "r");
    FILE *bios_version_file = fopen("/sys/class/dmi/id/bios_version", "r");
    FILE *bios_date_file = fopen("/sys/class/dmi/id/bios_date", "r");

    if (bios_vendor_file == NULL || bios_version_file == NULL || bios_date_file == NULL) {
        perror("Eroare la deschiderea fișierelor de BIOS");
        return;
    }

    char vendor[100], version[100], date[100];

    fgets(vendor, sizeof(vendor), bios_vendor_file);
    fgets(version, sizeof(version), bios_version_file);
    fgets(date, sizeof(date), bios_date_file);

    fprintf(f,"--BIOS--\n");
    fprintf(f,"Vendor: %s", vendor);
    fprintf(f,"Version: %s", version);
    fprintf(f,"Realease date: %s", date);

    fclose(bios_vendor_file);
    fclose(bios_version_file);
    fclose(bios_date_file);
}
 //aici trebuie harcodat, aici creez fisierul cu informatii despre sistem
void makeSysFile()
{
    FILE* f=fopen("/home/hiuhiubianca/Desktop/PSO_proiect/sistem.txt","w");
    if(f==NULL){
        perror("Eroare la deschiderea fisierului de sistem.");
        exit(-1);
    }

    struct utsname system_info;

    if (uname(&system_info) != 0) {
        perror("Eroare la obținerea informațiilor despre sistem");
        exit(-1);
    }

    fprintf(f,"\n\n----INFORMATII DESPRE SISTEM----\n");
    fprintf(f,"Sys name: %s\n", system_info.sysname);
    fprintf(f,"Node name: %s\n", system_info.nodename);
    fprintf(f,"Version: %s\n", system_info.version);
    fprintf(f,"Realease: %s\n\n",system_info.release);

    fprintf(f,"--CPU--\n");
    fprintf(f,"Arhitecture: %s\n", system_info.machine);
    CPUInfo(f);
    RAMInfo(f);
    BIOSInfo(f);

    fclose(f);
}
//este functia apelata in meniul clientului pentru a trimite la server informatiile despre sistem
void getSysInfo(int client_socket)
{
    FILE *file_to_send = fopen("/home/hiuhiubianca/Desktop/PSO_proiect/sistem.txt", "rb");

    if (file_to_send == NULL) {
    perror("Eroare la deschiderea fisierului de trimis.");
    exit(EXIT_FAILURE);
    }
    int len=0;
    char buffer[BUFFER_SIZE];
    fseek(file_to_send,0,SEEK_END);
    int fs=ftell(file_to_send);
    fseek(file_to_send,0,SEEK_SET);
    char fileSize[256];
    memset(fileSize,0,sizeof(fileSize));
    sprintf(fileSize,"%d",fs);
    //printf("%s\n",fileSize);
    len=strlen(fileSize);
    send(client_socket,&len,sizeof(int),0);
    send(client_socket,fileSize,len,0);

    int sentBytes=0;
    int remainData=fs;
    memset(buffer,0,sizeof(buffer));
    while(((sentBytes=fread(buffer,1,BUFFER_SIZE,file_to_send))>0)&&(remainData>0)){
        //printf("%s",buffer);
        //l=strlen(buffer);
        //printf("%d\n",l);
        send(client_socket,buffer,strlen(buffer),0);
        remainData-=sentBytes;
        //printf("%d\n",remainData);
    }
    fclose(file_to_send);
    //printf("Datele au fost trimise.\n");
}

//functie pentru primirea fisierelor de la server
unsigned char* base64_decode(const char *input, int length, int *output_length) {
    BIO *bio, *b64;

    unsigned char *buffer = (unsigned char *)malloc(length);
    memset(buffer, 0, length);

    bio = BIO_new_mem_buf(input, length);
    b64 = BIO_new(BIO_f_base64());
    bio = BIO_push(b64, bio);

    BIO_set_flags(bio, BIO_FLAGS_BASE64_NO_NL);
    *output_length = BIO_read(bio, buffer, length);

    BIO_free_all(bio);

    return buffer;
}

void recieveFileFromServer() {
    
    char buffer[MAX_SIZE];
    char filename[MAX_SIZE];
    int len=0;

    recv(client_socket,&len,sizeof(int),0);
    //printf("%d\n",len);
    recv(client_socket,filename,len,0);
    filename[strcspn(filename, "\n")] = '\0';
    int verify=strlen(filename);
    if(verify>len){
        filename[len]='\0';
    }
    //printf("%s\n\n",filename);
 
    //printf("%d\n",fileSize);
    int fileSize = 0;
    recv(client_socket, &fileSize, sizeof(int), 0);
    printf("%d",fileSize);

    if(fileSize==-1){
        printf("Fisierul nu exista.\n>");
    }

    char* newPath=(char*)malloc(sizeof(char)*(strlen(RECEIVED_DOCS_DIR)+strlen(filename)));
    strcpy(newPath,RECEIVED_DOCS_DIR);
    strcat(newPath, filename);
    //printf("%s\n",newPath);
    
    FILE *received_file = fopen(newPath, "wb");

    if (received_file == NULL) {
        perror("Error opening file");
        exit(EXIT_FAILURE);
    }


    //printf("Dimensiune: %d\n",fileSize);

    int total_received = 0;

    while (total_received < fileSize) {
        int data_len=0;
        recv(client_socket,&data_len,sizeof(int),0);
        //printf("DL: %d\n",data_len);
        char *file_buffer = (char *)malloc(data_len);
        if(file_buffer==NULL){
            perror("Eroare la alocare.");
            exit(EXIT_FAILURE);
        }
        int bytes_received = recv(client_socket, file_buffer, data_len, 0);
        
        int decoded_length = 0;
        unsigned char *decoded_data = base64_decode(file_buffer, bytes_received, &decoded_length);
        total_received += decoded_length;
        //printf("%s\n",decoded_data);
        fwrite(decoded_data, decoded_length, 1, received_file);
        
        free(decoded_data);
        free(file_buffer);        
    }

    fclose(received_file);
    //printf("Primit.\n");
    free(newPath);
}

//aici in functia de download am lasat ambele versiuni, pentru ca ambele sunt sensibile, uneori imi descarca fisierul, alteori doar il creeaza gol, iar uneori da eroarea 'bad file descriptor', am atasat o poza in pdf
void downloadFile()
{
    char filepath[MAX_SIZE];
    int len=0;

    recv(client_socket,&len,sizeof(int),0);
    recv(client_socket,filepath,len,0);

    filepath[strcspn(filepath, "\n")] = '\0';
    int lenght=strlen(filepath);
    if(lenght>len){
        filepath[len]='\0';
    }
    //printf("%s\n",filepath);

    int fileDescriptor = open(filepath, O_RDONLY);
    if (fileDescriptor == -1) {
        perror("Eroare la deschiderea fisierului.");
        return;
    }


    off_t fileSize = lseek(fileDescriptor, 0, SEEK_END);
    lseek(fileDescriptor, 0, SEEK_SET);

    if (send(client_socket, &fileSize, sizeof(fileSize), 0) == -1) {
        perror("Eroare la trimiterea dimensiunii fisierului");
        close(fileDescriptor);
        return;
    }

    off_t offset = 0;
    ssize_t sentBytes = sendfile(client_socket, fileDescriptor, &offset, fileSize);

    if (sentBytes == -1) {
        perror("Eroare la trimiterea fisierului");
    }

    printf("Fisierul %s a fost trimis cu succes.", filepath);

    close(fileDescriptor);

    /*FILE *file_to_send_ptr = fopen(filepath, "rb");

    if (file_to_send_ptr == NULL) {
        int error=-1;
        send(client_socket,&error,sizeof(int),0);
        perror("Eroare la deschiderea fisierului de trimis.");
        //exit(EXIT_FAILURE);
        return;
    }

    fseek(file_to_send_ptr, 0, SEEK_END);
    int fileSize = ftell(file_to_send_ptr);
    fseek(file_to_send_ptr, 0, SEEK_SET);
    printf("Dimensiune: %d\n",fileSize);

    send(client_socket, &fileSize, sizeof(int), 0);

    char *file_buffer = (char *)malloc(BUFFER_SIZE);
    int bytes_read = 0;


    while ((bytes_read = fread(file_buffer, 1, BUFFER_SIZE, file_to_send_ptr)) > 0) {
        //printf("%s\n",file_buffer);
        char *base64_data = base64_encode((const unsigned char *)file_buffer, bytes_read);
        int data_len=strlen(base64_data);
      
        send(client_socket,&data_len,sizeof(int),0);
        printf("DL:%d\n",data_len);
        send(client_socket, base64_data, strlen(base64_data), 0);

        free(base64_data);
        memset(file_buffer, 0, BUFFER_SIZE);
    }

    fclose(file_to_send_ptr);  
    free(file_buffer);*/

}

//executie comenzi
void getCommand() {
    char buffer[BUFFER_SIZE];
    memset(buffer, 0, sizeof(buffer));
    int bytes_received = recv(client_socket, buffer, sizeof(buffer) - 1, 0); 

    if (bytes_received <= 0) {
        perror("Error receiving data");
        exit(EXIT_FAILURE);
    }

    buffer[bytes_received] = '\0';

    //elimin orice newline de la sf de cuv
    buffer[strcspn(buffer, "\r\n")] = '\0'; 

    printf("Command received: '%s'\n", buffer);

   char *args[MAX_ARGS];
    int arg_count = 0;

    // verifica daca primul caracter e spatiu si sare peste el
    char *command = buffer;
    while (*command == ' ') {
        command++;
    }

    char *token = strtok(command, " ");
    while (token != NULL && arg_count < MAX_ARGS) {
        args[arg_count++] = token;
        token = strtok(NULL, " ");
    }

    if (arg_count >= MAX_ARGS) {
        fprintf(stderr, "Too many arguments\n");
        exit(EXIT_FAILURE);
    }

    args[arg_count] = NULL; //

    for (int i = 0; i < arg_count; i++) {
        printf("args[%d]: '%s'\n", i, args[i]);
    }

    int fd[2];
    if (pipe(fd) == -1) {
        perror("pipe");
        exit(EXIT_FAILURE);
    }

    pid_t pid = fork();
    if (pid == -1) {
        perror("fork");
        exit(EXIT_FAILURE);
    }

    if (pid == 0) { // child process
        close(fd[0]);  //inchidem capatul de citire
        dup2(fd[1], STDOUT_FILENO);  //redirectam ca outputul comenzii sa se afiseze in pipe si nu la consola
        close(fd[1]);

        // executa comanda
        execvp(args[0], args);
        perror("execvp");
        exit(EXIT_FAILURE);
    } else { // parent process
        close(fd[1]);  //inchidem capatul de scriere
        wait(NULL);

        // citeste output-ul comenzii
        char line_buffer[9024];
        memset(buffer, 0, BUFFER_SIZE);
        
        strcpy(buffer,"Comanda executata cu succes.\n");
        while (read(fd[0], line_buffer, sizeof(line_buffer)) > 0) {
                strcat(buffer, line_buffer);
            }

           
        
         // trimite rezultatele
            int bytes=send(client_socket, buffer, strlen(buffer), 0);
            if(bytes==-1)
            {
                perror("send din getCommand");
                exit(EXIT_FAILURE);
            }
            memset(buffer, 0, BUFFER_SIZE);
            memset(line_buffer,0,9024);
            close(fd[0]);
    }
}

//procese

//functia este pentru a lua procesele din /proc
void get_procese()
{
    DIR *dir;
    struct dirent *entry;

    // Deschide directorul /proc
    dir = opendir("/proc");

    if (dir == NULL) {
        perror("opendir");
        exit(EXIT_FAILURE);
    }


   // Parcurge directorul
   int j=0;
   int counter_procese=0;
    while ((entry = readdir(dir)) != NULL) {

        int valid_pid = 1;
        for (int i = 0; entry->d_name[i] != '\0'; i++) {
            if (!isdigit(entry->d_name[i])) {
                valid_pid = 0;
                break;
            }
        }
        if(valid_pid)
        {
            counter_procese++;
            char filename[1024];
            sprintf(filename, "/proc/%s/comm", entry->d_name);

            int fd_cmdline_file = open(filename, O_RDONLY);

            if (fd_cmdline_file ==-1)
            {
                perror("Eroare la deschiderea fisierului");
                exit(EXIT_FAILURE);
            } 
            else{
                //char cmdline[256];
                //fgets(cmdline, strlen(cmdline), cmdline_file);

                char buffer_citit[1024];
                int bytes=read(fd_cmdline_file,buffer_citit,sizeof(buffer_citit)-1);
                
                buffer_citit[bytes]='\0';
                if(bytes==-1)
                {
                    perror("Eroare la citirea din fisier");
                    exit(EXIT_FAILURE);
                }
                // procesele_curente[j]=(char*)malloc(strlen(buffer_citit)*sizeof(char));
                strcpy(pid_procese[j],entry->d_name);
                strcpy(procesele_curente[j],buffer_citit);
                j++;
                
                close(fd_cmdline_file);
                }
        }            
    }
      //int i=0;

    nr_proc=counter_procese;
    char counter_str[3];
    sprintf(counter_str,"%d",counter_procese);

}

void listeaza_procese()
{
    int bytes=send(client_socket,&nr_proc,sizeof(nr_proc),0);
    if(bytes==-1)
    {
        perror("send din listeaza proc");
        exit(EXIT_FAILURE);
    }
    //printf("MESAJUL: %s\n",procesele_curente);
    
    int i=0;
    char* nume=strtok(procesele_curente[i],"\n");
    char* pid_str=strtok(pid_procese[i],"\n");
    i++;
        
    while(nume)
    {
        int pid_int=atoi(pid_str);
        int lungime_nume=strlen(nume);
        int a=send(client_socket,&lungime_nume,sizeof(lungime_nume),0);
        if(a==-1)
        {
            perror("send1 din listeaza proc");
            exit(EXIT_FAILURE);
        }
        int b=send(client_socket,nume,strlen(nume),0);
        if(b==-1)
        {
            perror("send2 din listeaza proc");
            exit(EXIT_FAILURE);
        }
        int c=send(client_socket,&pid_int,sizeof(pid_int),0);
        if(c==-1)
        {
            perror("send3 din listeaza proc");
            exit(EXIT_FAILURE);
        }
        printf("S-A TRIMIS PROCESUL %s \n",nume);
        nume=strtok(procesele_curente[i],"\n");
        pid_str=strtok(pid_procese[i],"\n");
        i++;
    }
    printf("atat.\n");
    
}

void opreste_proces()
{
    int pid;
    int bytes=recv(client_socket,&pid,sizeof(pid),0);  // primeste numele prosului pe care vrea sa-l opreasca
    if(bytes==-1)
    {
        perror("recv din opreste proces");
        exit(EXIT_FAILURE);
    }
    printf("\n");
    printf("\n");

    printf("PROCESUL DAT LA TASTATURA: %d\n",pid);

        for(int i=0;i<nr_proc;i++)
        {
            char*pid_proc_salvat=strtok(pid_procese[i],"\n");
            int pid_salvat=atoi(pid_proc_salvat);
            if(pid==pid_salvat)
            {
                printf("PROCESUL PE CARE VREAU SA-L OPRESC: %d\n",pid_salvat);
                if(kill(pid_salvat,SIGTERM)==0)
                {
                    printf("Procesul cu pid-ul %d a fost oprit cu succes.\n",pid_salvat);
                }
                else
                {
                    perror("Eroare la oprirea procesului");
                    exit(EXIT_FAILURE);
                }
                
            }
        }


}

void meniu_procese()
{
    while(1)
    {
        char optiune_proc[100];
        int bytes=recv(client_socket,optiune_proc,100,0);
        if(bytes==-1)
        {
            perror("Eroare");
            exit(EXIT_FAILURE);
        }
        printf("OPTIUNE PRIMITA: %s\n",optiune_proc);
        if(strstr(optiune_proc,"listeaza")!=NULL)
        {
            //pentru listare procese
            listeaza_procese();
        }
        else if(strstr(optiune_proc,"opreste")!=NULL)
        {
            //oprire proces
            opreste_proces();
        }
        else if(strstr(optiune_proc,"exit")!=NULL)
        {
            break;
        }
        memset(optiune_proc,0,100);
    }
}

//comanda personalizata
void comanda_personalizata()
{
    char comanda[1024];
    memset(comanda, 0, sizeof(comanda));
    int bytes=recv(client_socket,comanda,1024,0);
    if(bytes==-1)
    {
        perror("recv din comanda pers");
        exit(EXIT_FAILURE);
    }

    char* comm=strtok(comanda,"\n");

    printf("COMANDA PERSONALIZATA: %s\n",comm);

    FILE* output;
    char continut[4096];

    if(strstr(comm,"afiseaza utilizatori")!=NULL)  //utilizatorii din sistem
    {
        output=popen("cat /etc/passwd | cut -d':' -f1","r");
        if(output==NULL)
        {
            perror("Eroare la output");
            exit(EXIT_FAILURE);
        }
        
    }
    else if(strstr(comm,"afiseaza grupurile")!=NULL) //grupurile din sistem
    {
        output=popen("cat /etc/group | cut -d':' -f1","r");
        if(output==NULL)
        {
            perror("Eroare la output");
            exit(EXIT_FAILURE);
        }
        
    }
    else if(strstr(comm,"afiseaza utilizatorul curent")!=NULL) //utilizatorul curent
    {
        output=popen("whoami","r");
        if(output==NULL)
        {
            perror("Eroare la output");
            exit(EXIT_FAILURE);
        }
        
    }
    else if(strstr(comm,"afiseaza numarul utilizatorilor")!=NULL) //numarul de utilizatori
    {
        output=popen("cat /etc/passwd | wc -l","r");
        if(output==NULL)
        {
            perror("Eroare la output");
            exit(EXIT_FAILURE);
        }
       
    }
    else if(strstr(comm,"cautare utilizator")!=NULL) //cautare user
    {
        // extrag user-ul din comanda personalizata
        char prop[100];
        strcpy(prop,"echo ");
        strcat(prop,comm);
        strcat(prop," | cut -d' ' -f3");
        FILE* obtine_user=popen(prop,"r");
        char user[100];
        fgets(user,sizeof(user),obtine_user);

        char*usr=strtok(user,"\n");
        pclose(obtine_user);

        printf("USER: %s\n",usr);

        //aici formez comanda pt linux
        char command[100];
        strcpy(command,"grep ");
        strcat(command,usr);
        strcat(command,"-w /etc/passwd | cut -d':' -f1");
        output=popen(command,"r");
        if(output==NULL)
        {
            perror("Eroare la output");
            exit(EXIT_FAILURE);
        }
        strcpy(continut,"Utilizatorul a fost gasit!\n");
        memset(prop,0,sizeof(prop));
        memset(user,0,sizeof(user));
        
    }
     else if(strstr(comm,"afisare informatii")!=NULL) //detalii user
    {
        char prop[100];
        strcpy(prop,"echo ");
        strcat(prop,comm);
        strcat(prop," | cut -d' ' -f3");
        FILE* obtine_user=popen(prop,"r");
        char user[100];
        fgets(user,sizeof(user),obtine_user);
        char* usr=strtok(user,"\n");
        pclose(obtine_user);

        char command[100];
        strcpy(command,"id ");
        strcat(command,usr);
        strcat(command," ");
        output=popen(command,"r");
        if(output==NULL)
        {
            perror("Eroare la output");
            exit(EXIT_FAILURE);
        }
        memset(prop,0,sizeof(prop));
        memset(user,0,sizeof(user));
        
    }
    
    comm=NULL;

    //memset(comm,0,sizeof(comm));
    memset(comanda,0,sizeof(comanda));

    
    char line[1024];
    
    strcpy(continut,"Comanda executata cu succes.\n");
    while(fgets(line,sizeof(line),output)!=NULL)
    {
        strcat(continut,line);
    }
    
    int lungime_str=strlen(continut);
    send(client_socket,&lungime_str,sizeof(lungime_str),0);

    int bytes1=send(client_socket,continut,strlen(continut),0);
    if(bytes1==-1)
    {
        perror("send din comanda pers");
        exit(EXIT_FAILURE);
    }

    printf("S-a trimis continutul.\n");

    memset(continut,0,sizeof(continut));
    memset(line,0,sizeof(line));
    pclose(output);
}

//practic meniul clientului, unde in functie de ce primeste de la server stie ce functie sa apeleze
void* recieveMessages(void* arg)
{
    char msg[MAX_SIZE];
    while(serverRunning)
    {
        memset(msg, 0, sizeof(msg));
        int bytesRead = recv(client_socket, msg, sizeof(msg),0);
        if(bytesRead!=0)
        {
            if (bytesRead == -1) 
            {
                printf("Eroare la receptionarea mesajului.\n");
                break;
            }
            else
            {
                //printf("\nMESAJ PRIMIT: %s\n",msg);
                if (strstr(msg, "infosistem") != NULL)
                {
                    getSysInfo(client_socket);
                    memset(msg,0,sizeof(msg));
                }
                if(strstr(msg,"comandapers")!=NULL)
                {
                    comanda_personalizata();
                    memset(msg,0,sizeof(msg));
                }
                if(strstr(msg,"comanda")!=NULL)
                {
                    getCommand();
                    memset(msg,0,sizeof(msg));
                }
                if(strstr(msg,"procese")!=NULL)
                {
                    meniu_procese();
                    memset(msg,0,sizeof(msg));
                }
                if(strstr(msg,"transfer")!=NULL)
                {
                    recieveFileFromServer();
                    memset(msg,0,sizeof(msg));
                }
                if(strstr(msg,"descarca")!=NULL)
                {
                    downloadFile();
                    memset(msg,0,sizeof(msg));
                }
                if(strstr(msg,"delogare")!=NULL)
                {
                    printf("\nDelogare de la server...\n");
                    exit(EXIT_SUCCESS);
                }
            }      
        }
    }
    return NULL;
}

//functie luata din laborator pentru parola, ascunde litera introdusa la tastatura
char getch(void) {
    char buf = 0;
    struct termios old = {0};
    fflush(stdout);
    if(tcgetattr(0, &old) < 0)
        perror("tcsetattr()");

    old.c_lflag &= ~ICANON;
    old.c_lflag &= ~ECHO;
    old.c_cc[VMIN] = 1;
    old.c_cc[VTIME] = 0;
    if(tcsetattr(0, TCSANOW, &old) < 0)
        perror("tcsetattr ICANON");
    if(read(0, &buf, 1) < 0)
        perror("read()");
    old.c_lflag |= ICANON;
    old.c_lflag |= ECHO;
    if(tcsetattr(0, TCSADRAIN, &old) < 0)
        perror("tcsetattr ~ICANON");
    return buf;
}



int main()
{
    struct sockaddr_in server_address;

    if((client_socket = socket(AF_INET, SOCK_STREAM, 0))==-1){
        perror("Eroare in crearea socketului.");
        exit(EXIT_FAILURE);
    }

    server_address.sin_family=AF_INET;
    server_address.sin_port=htons(SERVERPORT);

    if(inet_pton(AF_INET,SERVERIP,&server_address.sin_addr)==-1){
        perror("Eroare la transformarea adresei IP.");
        exit(EXIT_FAILURE);
    }

    if(connect(client_socket,(struct sockaddr*)&server_address,sizeof(server_address))==-1){
        perror("Eroare la conectare.");
        exit(EXIT_FAILURE);
    }
  
    get_procese();

    printf("Conexiunea la server s-a realizat cu succes.\n");
    printf("---AUTENTIFICARE---\n");
    printf("Introduceti datele:\n");
    char username[MAX_SIZE];
    char password[MAX_SIZE];
    printf("Nume utilizator: ");
    fgets(username,sizeof(username),stdin);
    username[strcspn(username,"\n")]='\0';
    send(client_socket,username,strlen(username),0);

    printf("Parola: ");
    
    char c;
    int i=0;
    while ((c = getch()) != '\n' && i < MAX_SIZE - 1) {
        password[i++] = c;  
        printf("*");
        fflush(stdout); 
    }
    password[i]='\0';
   // printf("PAROLA: %s\n",password);
    send(client_socket,password,strlen(password),0);

    char buffer[MAX_SIZE];
    memset(buffer,0,sizeof(buffer));
    read(client_socket,buffer,sizeof(buffer));

    if(strcmp(buffer,"Autentificare reusita.")==0)
    {
        printf("\nAutentificare reusita.\n");
        makeSysFile();

        if(pthread_create(&recvThread,NULL,recieveMessages,NULL)!=0)
        {
            perror("Eroare la crearea threadului.");
            exit(EXIT_FAILURE);
        }

        while(1)
        {
            memset(buffer,0,sizeof(buffer));
            printf(">");
            fgets(buffer,sizeof(buffer),stdin);
            buffer[strcspn(buffer,"\n")]='\0'; //folosita pentru a ne deloga de la server

            send(client_socket,buffer,strlen(buffer),0);

            if(strstr("exit",buffer)!=NULL)
            {
                printf("Delogare de la server...\n");
                close(client_socket);
                exit(EXIT_SUCCESS);
            }
        }
    
        pthread_join(recvThread,NULL);
    }

    if(strcmp(buffer,"Autentificare esuata.")==0){
        printf("Autentificare esuata.\n");
    }

    close(client_socket);
    return 0;
}