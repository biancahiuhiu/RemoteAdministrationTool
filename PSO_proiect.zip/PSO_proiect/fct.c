#include <stdio.h>
#include <sys/mman.h>
#include <sys/stat.h>        /* For mode constants */
#include <fcntl.h>           /* For O_* constants */
#include <unistd.h>
 
 
#define SHM_NAME	"my_shm"
#define SHM_SIZE	1024
 
int main(void)
{
	void *mem;	/* map address */
	int shm_fd;	/* memory descriptor */
	int rc;
 
	/* create shm */
	shm_fd = shm_open(SHM_NAME, O_CREAT | O_RDWR, 0644);
 
	/* resize shm to fit our needs */
	rc = ftruncate(shm_fd, SHM_SIZE);
 
	mem = mmap(0, SHM_SIZE, PROT_WRITE | PROT_READ, MAP_SHARED, shm_fd, 0);
 
	/* write number in shm */
	((int*)mem)[0] = 2011;
	printf("mem[0] = %d\n", ((int*)mem)[0]);
 
	/* unmap shm */
	rc = munmap(mem, SHM_SIZE);
 
	/* close descriptor */
	rc = close(shm_fd);
 
	rc = shm_unlink(SHM_NAME);
 
	return 0;
}