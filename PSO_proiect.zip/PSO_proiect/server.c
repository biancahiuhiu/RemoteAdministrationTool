#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <pthread.h>
#include <stdbool.h>
#include <sys/select.h>
#include <openssl/bio.h>
#include <openssl/evp.h>
#include <openssl/buffer.h>
#include <sys/sendfile.h>

#define SERVERPORT 1234
#define MAX_CLIENTS 5
#define MAX_USERS 10
#define MAX_SIZE 1024
#define BUFFER_SIZE 1024
#define IP_LEN    16
#define RECEIVED_DOCS_DIR "./ReceivedDocumentsServer/"
#define LOGGER "./log.txt"

int serverRunning=1;
int server_socket;
int client_socket;
int ConnectedClientsNb=0;

pthread_mutex_t clientsMutex;
int conex=0;
pthread_t clientThreadID[MAX_CLIENTS];

struct Clients{
    char IP_Address[IP_LEN];
    int socket;
};

struct Users{
    char* username;
    char* password;
};

struct Users utilizatori[MAX_USERS]; //stocam toti utilizatorii permisi intr-o structura
struct Clients connectedClients[MAX_CLIENTS]; // la fel si clientii conectati

//functie utilizata in logger, am pastrat si loggerul ulterior si ultima versiune a sa, de accea sunt doua txt uri
char* getIPClient(int client_socket)
{
    for(int i=0;i<ConnectedClientsNb;i++){
        if(connectedClients[i].socket==client_socket){
            return connectedClients[i].IP_Address;
        }
    }
    return NULL;
}

/*data functions de pe StackOverflow*/
void modifyLogger(char* IP,char* command,char* status)
{
    FILE* logFile=fopen(LOGGER,"a+");
    if(logFile==NULL){
        perror("Eroare la deschiderea fisierului de log.");
        exit(EXIT_FAILURE);
    }

    time_t t=time(NULL);
    struct tm* tm=localtime(&t);
    char data[64];
    strftime(data,sizeof(data),"%c",tm);

    fprintf(logFile,"Date: %s\n",data);
    fprintf(logFile,"Command: %s\n",command);
    fprintf(logFile,"Status: %s\n",status);
    fprintf(logFile,"IP Client: %s\n",IP);
    
    fprintf(logFile,"--------------------\n");

    fflush(logFile);
    fclose(logFile);
}

int numberOfUsers(const char* filename)
{
    int count=0;
    FILE* f=fopen(filename,"r");
    if(f==NULL){
        perror("Eroare la deschiderea fisierului cu utilizatori.");
        exit(EXIT_FAILURE);
    }
    char buff[MAX_SIZE];
    while(fgets(buff,1024,f)!=NULL){
        count++;
    }

    fclose(f);
    return count;
}

//adaugarea conturilor in structura
void addAllAccounts(const char* filename,int nbAcc)
{
    FILE* f=fopen(filename,"r");
    if(f==NULL){
        perror("Eroare la deschiderea fisierului cu utilizatori.");
        exit(EXIT_FAILURE);
    }

    char buffer[MAX_SIZE];
    int i=0;

    while(fgets(buffer,MAX_SIZE,f)!=NULL && i<nbAcc){
        char* p=strtok(buffer," \t");
        utilizatori[i].username=(char*)malloc(sizeof(char)*strlen(p));
        strcpy(utilizatori[i].username,p);
        
        p=strtok(NULL,"\n");
        utilizatori[i].password=(char*)malloc(sizeof(char)*strlen(p));
        strcpy(utilizatori[i].password,p);
        i++;
    }
    fclose(f);
}

bool verifyAccount(int client_socket)
{
    char username[MAX_SIZE];
    char password[MAX_SIZE];

    int bytesReadUser=read(client_socket,username,sizeof(username));
    if(bytesReadUser==-1){
        perror("Eroare citire username.");
        exit(EXIT_FAILURE);
    }
    username[bytesReadUser]='\0';

    int bytesReadPasswd=read(client_socket,password,sizeof(password));
    if(bytesReadPasswd==-1){
        perror("Eroare citire parola.");
        exit(EXIT_FAILURE);
    }
    password[bytesReadPasswd]='\0';
    
    for(int i=0;i<2;i++){
        if((strcmp(password,utilizatori[i].password)==0) && (strcmp(username,utilizatori[i].username)==0)){
            return true;
        }
    }
    return false;
}

//adaugarea unui client si verificarea serverului
void addClient(struct Clients client)
{
    pthread_mutex_lock(&clientsMutex);

    if(ConnectedClientsNb==MAX_CLIENTS){
        printf("Serverul este full.\n");
        return;
    }

    connectedClients[ConnectedClientsNb]=client;
    ConnectedClientsNb++;

    pthread_mutex_unlock(&clientsMutex);
}

void removeClient(int clientSocket)
{
    pthread_mutex_lock(&clientsMutex);

    for(int i=0;i<ConnectedClientsNb;i++)
    {
        if(ConnectedClientsNb==1)
        {
            ConnectedClientsNb--;
            conex--;
            break;
        }

        if(connectedClients[i].socket==clientSocket)
        {
            for(int j=i;j<ConnectedClientsNb-1;j++){
                connectedClients[j]=connectedClients[j+1];
                clientThreadID[j]=clientThreadID[i];
            }
            ConnectedClientsNb--;
            conex--;
            break;
        }
    }


    pthread_mutex_unlock(&clientsMutex);
}

void closeAllConections()
{
    for(int i=0;i<ConnectedClientsNb;i++){
        int client_socket=connectedClients[i].socket;
        char* msg="delogare";
        send(client_socket,msg,strlen(msg),0);

        close(client_socket);
    }
    
    ConnectedClientsNb=0;
    conex=0;
}

void printConnectedClients()
{
    if(ConnectedClientsNb==0){
        printf("\n---STARE SISTEM---\n");
        printf("Deocamdata nu este niciun client conectat.\n");
    }
    else {
        printf("\n---STARE SISTEM---\n");
        printf("Clientii conectati sunt:\n");
        
        pthread_mutex_lock(&clientsMutex);
        for(int i=0;i<ConnectedClientsNb;i++){
            printf("->Clientul %d: %s\n",i+1,connectedClients[i].IP_Address);
        }
        pthread_mutex_unlock(&clientsMutex);
    }
}

//functia pentru punctul 2, primeste de la server dimensiunea isierului si apoi afiseaza in terminal toate informatiile din fisier
void getSysInfo(int client_socket)
{
 
    for(int i=0;i<ConnectedClientsNb;i++){
        if(connectedClients[i].socket==client_socket){
            printf("\n\nClientul %s:\n",connectedClients[i].IP_Address);
        }
    }
    char buffer[MAX_SIZE];
    int len=0;

    recv(client_socket,&len,sizeof(int),0);
    recv(client_socket,buffer,len,0);
    buffer[strcspn(buffer,"\n")]='\0';
    int fileSize=atoi(buffer);

    int remainData=fileSize;
    
    int bytesReceived=0;
    memset(buffer,0,sizeof(buffer));
    while((remainData>0) && ((bytesReceived=recv(client_socket,buffer,MAX_SIZE,0))>0))
    {
        printf("%s",buffer);
        remainData-=bytesReceived;
    }


    //modifyLogger(IP_Address,"System Information","SUCCESS");
}

//pentru transfer
char* getFileNameFromPath(char *path) 
{
    char *filename = strrchr(path, '/');
    if (filename == NULL) {
        return path;
    } else {
        return filename + 1;
    }
}

char* base64_encode(const unsigned char *input, int length) {
    BIO *bio, *b64;
    BUF_MEM *bufferPtr;

    b64 = BIO_new(BIO_f_base64());
    bio = BIO_new(BIO_s_mem());
    bio = BIO_push(b64, bio);

    BIO_set_flags(bio, BIO_FLAGS_BASE64_NO_NL);
    BIO_write(bio, input, length);
    BIO_flush(bio);
    BIO_get_mem_ptr(bio, &bufferPtr);

    // Se aloca un octet suplimentar pentru terminatorul null
    char *buffer = (char *)malloc(bufferPtr->length + 1);
    memcpy(buffer, bufferPtr->data, bufferPtr->length);
    buffer[bufferPtr->length] = '\0'; // Adaugare terminator null

    BIO_free_all(bio);

    return buffer;
}

void sendFileToClient(int client_socket)
{
    char* IP_Address=getIPClient(client_socket);
    printf("\n---Clientul %s---\n",IP_Address);
    printf("---TRANSFER DE FISIERE---\n");
    printf("Tasteaza calea catre fisierul pe care doresti sa il trimiti.\n");

    char file_to_send[MAX_SIZE];
            
    int readPath = read(0, file_to_send, sizeof(file_to_send));
    if (readPath == -1) {
        perror("Eroare la citirea caii.");
        modifyLogger(IP_Address,"File Transfer","FAILED");
        return;
    }
    file_to_send[strcspn(file_to_send, "\n")] = '\0';
            
    char* filename=getFileNameFromPath(file_to_send);
    int len=strlen(filename);
    //printf("%d\n",len);
    send(client_socket,&len,sizeof(int),0);
    send(client_socket,filename,len,0);

    FILE *file_to_send_ptr = fopen(file_to_send, "rb");

    if (file_to_send_ptr == NULL) {
        int error=-1;
        send(client_socket,&error,sizeof(int),0);
        perror("Eroare la deschiderea fisierului de trimis.");
        modifyLogger(IP_Address,"File Transfer","FAILED");
        //exit(EXIT_FAILURE);
        return;
    }

    fseek(file_to_send_ptr, 0, SEEK_END);
    int fileSize = ftell(file_to_send_ptr);
    fseek(file_to_send_ptr, 0, SEEK_SET);
    //printf("Dimensiune: %d\n",fileSize);

    send(client_socket, &fileSize, sizeof(int), 0);

    char *file_buffer = (char *)malloc(BUFFER_SIZE);
    int bytes_read = 0;


    while ((bytes_read = fread(file_buffer, 1, BUFFER_SIZE, file_to_send_ptr)) > 0) {
        //printf("%s\n",file_buffer);
        char *base64_data = base64_encode((const unsigned char *)file_buffer, bytes_read);
        int data_len=strlen(base64_data);
      
        send(client_socket,&data_len,sizeof(int),0);
        //printf("DL:%d\n",data_len);
        send(client_socket, base64_data, strlen(base64_data), 0);

        free(base64_data);
        memset(file_buffer, 0, BUFFER_SIZE);
    }

    fclose(file_to_send_ptr);  
    free(file_buffer);
    printf("Fisierul %s a fost trimis cu succes.",filename);
    modifyLogger(IP_Address,"File Transfer","SUCCESS");
}

/*unsigned char* base64_decode(const char* input, int length, int* output_length) {
    BIO *bio, *b64;

    unsigned char *buffer = (unsigned char *)malloc(length);
    memset(buffer, 0, length);

    bio = BIO_new_mem_buf(input, length);
    b64 = BIO_new(BIO_f_base64());
    bio = BIO_push(b64, bio);

    BIO_set_flags(bio, BIO_FLAGS_BASE64_NO_NL);
    *output_length = BIO_read(bio, buffer, length);

    BIO_free_all(bio);

    return buffer;
}*/

//am precizat si in client, am pastrat ambele versiuni de cod din cauza erorilor ce apar
void downloadFile(int client_socket)
{
    printf("\n---DESCARCA FISIERE---\n");
    printf("Tastati calea catre fisierul pe care doriti sa-l descarcati: \n");
    char file_to_recv[BUFFER_SIZE];
    char* IP_Address=getIPClient(client_socket);
            
    int path = read(0, file_to_recv, sizeof(file_to_recv));
    if (path == -1) {
        perror("Eroare la citirea caii.");
        modifyLogger(IP_Address,"File Download","FAILED");
        return;
    }
    file_to_recv[strcspn(file_to_recv, "\n")] = '\0';
    int lenght=strlen(file_to_recv);

    send(client_socket,&lenght,sizeof(int),0);
    send(client_socket,file_to_recv,lenght,0);

     
    char* name=getFileNameFromPath(file_to_recv);
    char* newPath=(char*)malloc(sizeof(char)*(strlen(RECEIVED_DOCS_DIR)+strlen(name)));
    strcpy(newPath,RECEIVED_DOCS_DIR);
    strcat(newPath, name);
    newPath[strcspn(newPath, "\n")] = '\0';
    printf("%s\n",newPath);

    char buffer[BUFFER_SIZE];

    int fileDescriptor = open(newPath, O_WRONLY | O_CREAT | O_TRUNC, 0666);
    if (fileDescriptor == -1) {
        perror("Eroare la deschiderea fisierului pentru scriere");
        return;
    }

    off_t fileSize;
    ssize_t receivedBytes = recv(client_socket, &fileSize, sizeof(fileSize), 0);
    if (receivedBytes == -1) {
        perror("Eroare la primirea dimensiunii fisierului");
        close(fileDescriptor);
        return;
    }

    
    ssize_t remainingBytes = fileSize;
    ssize_t receivedTotal = 0;

    while (remainingBytes > 0) {
        ssize_t receivedBytes = recv(client_socket, &buffer, sizeof(buffer), 0);
        if (receivedBytes <= 0) {
            perror("Eroare la primirea datelor fisierului");
            close(fileDescriptor);
            return;
        }

        ssize_t writtenBytes = write(fileDescriptor, buffer, receivedBytes);
        if (writtenBytes == -1) {
            perror("Eroare la scrierea in fisier");
            close(fileDescriptor);
            return;
        }

        remainingBytes -= receivedBytes;
        receivedTotal += receivedBytes;
    }

    close(fileDescriptor);
    printf("Fisierul %s a fost descarcat.\n",name);
    modifyLogger(IP_Address,"File Download","SUCCESS");

        /*int fileSize = 0;
       recv(client_socket, &fileSize, sizeof(int), 0);
       printf("%d",fileSize);

       if(fileSize==-1){
           printf("Fisierul nu exista.\n>");
       }


       FILE *received_file = fopen(newPath, "wb");

       if (received_file == NULL) {
           perror("Error opening file");
           exit(EXIT_FAILURE);
       }


       printf("Dimensiune: %d\n",fileSize);

       int total_received = 0;

       while (total_received < fileSize) {
           int data_len=0;
           recv(client_socket,&data_len,sizeof(int),0);
           printf("DL: %d\n",data_len);
           char *file_buffer = (char *)malloc(data_len);
           if(file_buffer==NULL){
               perror("Eroare la alocare.");
               exit(EXIT_FAILURE);
           }
           int bytes_received = recv(client_socket, file_buffer, data_len, 0);

           int decoded_length = 0;
           unsigned char *decoded_data = base64_decode(file_buffer, bytes_received, &decoded_length);
           total_received += decoded_length;
           //printf("%s\n",decoded_data);
           fwrite(decoded_data, decoded_length, 1, received_file);

           free(decoded_data);
           free(file_buffer);
       }

       fclose(received_file);
       //printf("Primit.\n");
       free(newPath);*/

}

//trimite comanda , iar clientul o executa si trimite outputul
void trimite_comanda(int server_socket)
{
    char mesaj_server[9024];
    char* comanda=(char*)malloc(1024*sizeof(char));
     
    printf("\n---COMENZI DIN TERMINAL---\n");

    write(STDOUT_FILENO,"Tastati aici comanda pe care doriti sa o introduceti: ",55);
    read(STDIN_FILENO,comanda,1024);
    int bytes=send(server_socket,comanda,strlen(comanda),0);
    if(bytes==-1)
    {
        perror("send din trimite_comanda");
        exit(EXIT_FAILURE);
    }
    memset(comanda,0,1024);
    free(comanda);
    memset(mesaj_server, 0, sizeof(mesaj_server));
    int bytes1=recv(server_socket, mesaj_server, sizeof(mesaj_server), 0);
    if(bytes1==-1)
    {
        perror("recv din trimite_comanda");
        exit(EXIT_FAILURE);
    }
    printf("Raspunsul serverului:\n%s\n", mesaj_server);
    
            
}


//pentru optiunea 5 , cu procesele
void gestionare_procese(int server_socket)
{
    printf("\n---PROCESE---\n");
    while(1)
    {
        char optiune[100];
        memset(optiune,0,sizeof(optiune));
        printf("\n");
        printf("1. Listeaza procesele.\n");
        printf("2. Opreste proces.\n");
        printf("3. Exit\n");
        printf("Pentru listare introduceti codul 'listeaza'\n");
        printf("Pentru oprire introduceti codul 'opreste'\n");
        printf("Pentru iesire introduceti 'exit'\n");
        printf("Tastati optiunea aici: ");
        scanf("%s",optiune);
        while(strstr(optiune,"listeaza")==NULL &&strstr(optiune,"opreste")==NULL&& strstr(optiune,"exit")==NULL)
        {
            printf("\nOptiunea nu este valida, introduceti o optiune valida: ");
            scanf("%s",optiune);
        }
        printf("OPTIUNE TRIMISA: %s\n",optiune);
        int a=send(server_socket,optiune,strlen(optiune),0);
        if(a==-1)
        {
            perror("send1 din procese");
            exit(EXIT_FAILURE);
        }
        int opt=0;
        if(strstr(optiune,"listeaza")!=NULL)
        {
            opt=1;
        }
        else if(strstr(optiune,"opreste")!=NULL)
        {
            opt=2;
        }
        else if(strstr(optiune,"exit")!=NULL)
        {
            opt=3;
        }
        switch(opt)
        {
            case 1:
                char buffer[100];
                int nr_procese;

                int b=recv(server_socket,&nr_procese,sizeof(nr_procese),0);
                if(b==-1)
                {
                    perror("recv1 din procese");
                    exit(EXIT_FAILURE);
                }
                printf("Numar de procese: %d\n",nr_procese);
                
                printf("Raspuns :\n");
                for(int i=0;i<nr_procese;i++)
                {
                    //char lungime[3];
                    int lungime;
                    int pid;
                    int c=recv(server_socket,&lungime,sizeof(lungime),0);
                    if(c==-1)
                    {
                        perror("recv2 din procese");
                        exit(EXIT_FAILURE);
                    }
                    int d=recv(server_socket,buffer,lungime,0);
                    if(d==-1)
                    {
                        perror("recv3 din procese");
                        exit(EXIT_FAILURE);
                    }
                    int e=recv(server_socket,&pid,sizeof(pid),0); 
                    if(e==-1)
                    {
                        perror("recv4 din procese");
                        exit(EXIT_FAILURE);
                    }
                    printf("Nume procese: %s cu pid-ul %d\n",buffer,pid);
                    memset(buffer,0,sizeof(buffer));
                    pid=0;

                }
            break;
            case 2: 
                int pid;
                printf("Tastati aici pidul procesului pe care vreti sa-l opriti: ");
                scanf("%d",&pid);
                int f=send(server_socket,&pid,sizeof(pid),0);
                if(f==-1)
                {
                    perror("send2 din procese");
                    exit(EXIT_FAILURE);
                }
                pid=0;
                
                break;
            default:
                break;
        }
        if(strstr(optiune,"exit")!=NULL)
        {
            break;
        }
    }
}

//trimite comenzile personalizate, iar clientul le executa ca pe unele linux si trimite outputul inapoi
void gestionare_comenzi_personalizate(int server_socket) {
    printf("\n---COMENZI PERSONALIZATE---\n");
    char comanda_pers[1024] = {0};
    printf("Comenzile sunt:\n");
    printf("1 ---> afiseaza utilizatori\n");
    printf("2 ---> afiseaza grupurile\n");
    printf("3 ---> afiseaza utilizatorul curent\n");
    printf("4 ---> afiseaza numarul utilizatorilor\n");
    printf("5 ---> cautare utilizator [nume]\n");
    printf("6 ---> afisare informatii [nume utilizator]\n");

    write(STDOUT_FILENO, "Tastati aici comanda personalizata: ", 37);
    read(STDIN_FILENO, comanda_pers, 1024);

    int bytes = send(server_socket, comanda_pers, strlen(comanda_pers), 0);
    if (bytes <= 0) {
        perror("send din comenzi personalizate");
        exit(EXIT_FAILURE);
    }

    printf("S-A TRIMIS COMANDA PERSONALIZATA: %s\n", comanda_pers);

    int lungime;
    int bytes_received = recv(server_socket, &lungime, sizeof(int), MSG_WAITALL);
    if (bytes_received <= 0) {
        perror("recv lungime din comenzi personalizate");
        exit(EXIT_FAILURE);
    }
    printf("Lungime: %d\n", lungime);

    if (lungime > 0) {
        char *output = (char *)malloc(lungime + 1); 
        if (output == NULL) {
            perror("malloc pentru output");
            exit(EXIT_FAILURE);
        }

        bytes_received = recv(server_socket, output, lungime, MSG_WAITALL);
        if (bytes_received <= 0) {
            perror("recv output din comenzi personalizate");
            free(output);
            exit(EXIT_FAILURE);
        }

        output[lungime] = '\0'; 
        printf("Raspunsul serverului: \n%s\n", output);

        free(output);
    }
}
//functie asociata doar pentru download, desi functioneaza mai bine doar cand un singur client este conectat la server
void sendCommandToAClient(int commandType)
{
    printConnectedClients();
    if(ConnectedClientsNb!=0)
    {
        printf("Alege clientul pe care il doresti: ");
        char clientIP[IP_LEN];
        scanf("%s", clientIP);

        int client_socket=-1;
        for(int i=0;i<ConnectedClientsNb;i++){
            if(strcmp(clientIP,connectedClients[i].IP_Address)==0){
                client_socket=connectedClients[i].socket;
                break;
            }
        }

        if(client_socket==-1){
            printf("Clientul nu a fost gasit.\n");
            return;
        }

        char *msj=NULL;
        if(commandType==7){
            msj="descarca";
        }

  
        send(client_socket,msj,strlen(msj),0);
        //printf("COD TRIMIS: %s\n",msj);

        switch(commandType)
        {
            case 7:
                downloadFile(client_socket);
                printf("\n----------------------------\n");
                break;
            default:
                break;
        }

    }
}

//pentru a trimite comenzile la client si a apela functiile necesare in server
void sendCommandToAllClients(int commandType)
{
    if (ConnectedClientsNb > 0) {
        pthread_mutex_lock(&clientsMutex);

        for (int i = 0; i < ConnectedClientsNb; i++)
        {
            client_socket=connectedClients[i].socket;
            if(client_socket==-1){
            printf("Clientul nu a fost gasit.\n");
            return;
            }

            char *msj=NULL;

            if(commandType==2){
            msj="infosistem";
            }
            if(commandType==4){
                msj="transfer";
            }
            if(commandType==7){
                msj="descarca";
            }
            if(commandType==3)
            {
                msj="comanda";
            }
            if(commandType==5)
            {
                msj="procese";
            }
            if(commandType==6)
            {
                msj="comandapers";
            }


            send(client_socket,msj,strlen(msj),0);
            //printf("COD TRIMIS: %s\n",msj);

            switch(commandType)
            {
            case 2:
                getSysInfo(client_socket);
                printf("\n----------------------------\n");
                break;
            case 3:
                trimite_comanda(client_socket);
                printf("\n----------------------------\n");
                break;
            case 4:
                sendFileToClient(client_socket);
                printf("\n----------------------------\n");
                break;
            case 5:
                gestionare_procese(client_socket);
                printf("\n----------------------------\n");
                break;
            case 6:
                gestionare_comenzi_personalizate(client_socket);
                printf("\n----------------------------\n");
                break;
            case 7:
                downloadFile(client_socket);
                printf("\n----------------------------\n");
                break;
            default:
                break;
            }

        }

        pthread_mutex_unlock(&clientsMutex);

    }
}


void* handleClient(void* arg)
{
    int client_socket=*((int*)arg);
    free(arg);

    struct sockaddr_in client_address;
    socklen_t client_address_len=sizeof(client_address);

    // Obtinem adresa IP a clientului
    if(getpeername(client_socket, (struct sockaddr*)&client_address,&client_address_len)!=0){
        perror("Nu s-a putut obtine adresa IP a clientului.");
        close(client_socket);
        return NULL;
    }

    char clientIP[IP_LEN];
    struct Clients client;

    if(inet_ntop(AF_INET,&(client_address.sin_addr),clientIP,IP_LEN)!=NULL){
        //printf("Clientul cu adresa IP %s s-a conectat.\n",clientIP);
        strncpy(client.IP_Address,clientIP,IP_LEN);
        client.socket=client_socket;
    }

    if(verifyAccount(client_socket)==false){
        char* msg="Autentificare esuata.";
        send(client_socket,msg,strlen(msg),0);
        printf("%s",client.IP_Address);
        modifyLogger(client.IP_Address,"Authentication","FAILED");
        close(client_socket);
        //printf("Clientul cu adresa IP %s nu s-a putut autentifica.\n",clientIP);
        return NULL;
    }

   //printf("Clientul cu adresa IP %s s-a autentificat cu succes.\n",clientIP);
    char* msg="Autentificare reusita.";
    send(client_socket,msg,strlen(msg),0);
  
    modifyLogger(client.IP_Address,"Authentication","SUCCESS");
    addClient(client);

    char buffer[MAX_SIZE];
    while(1){
        memset(buffer,0,sizeof(buffer));
        int bytesRead=read(client_socket,buffer,sizeof(buffer));
        if(bytesRead<=0){
            break;
        }
        else if(strstr(buffer,"exit")!=NULL){
            printf("\n-------\n");
            printf("Clientul cu adresa ip %s s-a delogat.\n",clientIP);
            removeClient(client_socket);
            break;
        }
    }

    close(client_socket);
    return NULL;
}

void* commandThreadMenu(void* arg)
{
    do{
        printf("\n----MENIU----\n");
        printf("1.Afiseaza toti clientii conectati.\n");
        printf("2.Informatii despre sistem.\n");
        printf("3.Trimite o comanda.\n");
        printf("4.Transfera fisiere.\n");
        printf("5.Gestioneaza procesele.\n");
        printf("6.Trimite o comanda personalizata.\n");
        printf("7.Descarca un fisier.\n");
        printf("8.Inchide toate conexiunile.\n");
        printf("9.Delogare.\n");
        printf("Introduceti optiune: ");

        int opt;
        scanf("%d",&opt);
        switch(opt)
        {
            case 1:
                printConnectedClients();
                modifyLogger("ServerCmd","Print Clients","SUCCESS");
                break;
            case 2:
            case 3:
            case 4:
            case 5:
            case 6:
                sendCommandToAllClients(opt);
                break;
            case 7:
                sendCommandToAClient(opt);
                break;
            case 8:
                modifyLogger("ServerCmd","Close connections","SUCCESS");
                closeAllConections();
                break;
            case 9:
                printf("\nDelogare de la server...\n");
                modifyLogger("ServerCmd","Log Out","SUCCESS");
                closeAllConections();
                close(server_socket);
                exit(EXIT_SUCCESS);
                break;
            default:
                break;
        }
  
    }while(serverRunning);

    return NULL;
}


int main()
{
    pthread_mutex_init(&clientsMutex,NULL);

    //crearea socketului pentru server
    server_socket=socket(AF_INET,SOCK_STREAM,0);
    if (server_socket == -1) {
        perror("Eroare la crearea socket-ului");
        exit(EXIT_FAILURE);
    }

    // Setarea atributele serverului
    struct sockaddr_in server_address;
    server_address.sin_family = AF_INET;
    server_address.sin_port = htons(SERVERPORT); 
    server_address.sin_addr.s_addr =  INADDR_ANY; //constanta reprezintă o constantă specială care indică faptul că serverul va asculta la oricare adresă IP Legăm socket-ul la adresa și portul specificate
    if (bind(server_socket, (struct sockaddr*)&server_address, sizeof(server_address)) == -1) {   // efectuează legarea socket-ului server_socket la adresa specificată în structura server_address și portul specificat în aceeași structură
        perror("Eroare la legarea socket-ului");
        exit(EXIT_FAILURE);
    }

    // Ascultăm pentru conexiuni de la clienți
    if(listen(server_socket,MAX_CLIENTS)==-1){
        perror("Eroare la ascultarea conexiunilor.");
        exit(EXIT_FAILURE);
    }

    printf("Serverul asculta pe portul %d... \n",SERVERPORT);

    int nbUsers=numberOfUsers("accounts.txt");
    addAllAccounts("accounts.txt",nbUsers);

    // Cream firul de executie pentru meniul de comenzi
    pthread_t commandThreadID;
    if(pthread_create(&commandThreadID,NULL,commandThreadMenu,NULL)!=0){
        perror("Eroare la crearea thread-ului pentru comenzi.");
        exit(EXIT_FAILURE);
    } 

    while(serverRunning)
    {
        struct sockaddr_in client_address;
        socklen_t client_address_len=sizeof(client_address);
        
        client_socket=accept(server_socket, (struct sockaddr*)&client_address, &client_address_len);
        if (client_socket == -1) {
            perror("Eroare la acceptarea conexiunii de la client.");
            continue;
        }

        // Cream un pointer pentru descriptorul socketului clientului pentru a fi trasmis catre threadul clientului
        int* clientSocketPtr=(int*)malloc(sizeof(int));
        *clientSocketPtr=client_socket;

        if(pthread_create(&clientThreadID[conex],NULL,handleClient,clientSocketPtr)==-1){
            perror("Eroare la crearea firului de executie pentru client.");
            free(clientSocketPtr);
            close(client_socket);
            continue;
        }  

        conex++;  
    }

    for(int i=0;i<ConnectedClientsNb;i++)
    {
        free(utilizatori[i].username);
        free(utilizatori[i].password);
    }


    pthread_mutex_destroy(&clientsMutex);
    return 0;
}