#include <mqueue.h>
#include <string.h>
#include <stdio.h>
#include <errno.h>
 
 
/* Set buffer size at least the default maxim size of the queue
  * found in/proc/sys/kernel/msgmax */
#define BUF_SIZE 	(1<<13)
#define TEXT		"test message"
#define NAME		"/test_queue"
 
char buf[BUF_SIZE];
 
int main(int argc, char **argv)
{
	unsigned int prio = 10;
	int rc;
	mqd_t m;
 
	m = mq_open(NAME, (argc>1 ? O_CREAT : 0) | O_RDWR, 0666, NULL);
 
 
	if (argc > 1) {
		/* server sending message */
 
		rc = mq_send(m, TEXT, strlen(TEXT), prio);
 
 
		rc = mq_close(m);
 
 
	} else {
		/* client receiving message */
 
		rc = mq_receive(m, buf, BUF_SIZE, &prio);
 
 
		printf("received: %s\n", buf);
 
		rc = mq_close(m);
 
 
		rc = mq_unlink(NAME);
 
	}
 
	return 0;
}